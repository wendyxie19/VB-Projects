﻿Public Class Form1
    Private startPoint As Point
    Private isDragging As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.Size = PictureBox1.Image.Size ' Set PictureBox size to image size
    End Sub

    Private Sub PictureBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown
        ' Record the starting point for the swipe
        startPoint = e.Location
        isDragging = True
    End Sub

    Private Sub PictureBox1_MouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseMove
        If isDragging Then
            ' Calculate the new position
            Dim dx As Integer = e.Location.X - startPoint.X
            Dim dy As Integer = e.Location.Y - startPoint.Y

            ' Update the PictureBox location within the Panel, so it doesn’t go out of bounds
            Dim newLeft As Integer = Math.Max(Math.Min(PictureBox1.Left + dx, 0), Panel1.Width - PictureBox1.Width)
            Dim newTop As Integer = Math.Max(Math.Min(PictureBox1.Top + dy, 0), Panel1.Height - PictureBox1.Height)

            PictureBox1.Left = newLeft
            PictureBox1.Top = newTop
        End If
    End Sub

    Private Sub PictureBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseUp
        ' End the swipe when the mouse button is released
        isDragging = False
    End Sub


End Class