﻿Public Class Form1

    Private boxArray() As Box = New Box(4) {} 'Have to use array 
    Private boxCounter As Integer = 1
    Private boxCount As Integer = 0 ' Track the number of active boxes
    Private deletedIndices As New List(Of Tuple(Of Integer, Integer)) ' List to store deleted positions and box numbers

    ' Button to create a new box
    Private Sub btnCreateBox_Click(sender As Object, e As EventArgs) Handles btnCreateBox.Click
        ' Resize array if necessary 
        If boxCount >= boxArray.Length AndAlso deletedIndices.Count = 0 Then
            ReDim Preserve boxArray(boxArray.Length * 2 - 1)
        End If

        ' Check if there are any deleted slots available
        Dim insertIndex As Integer
        Dim newBoxNumber As Integer
        If deletedIndices.Count > 0 Then
            ' Use the first available deleted position and retrieve its box number
            insertIndex = deletedIndices(0).Item1
            newBoxNumber = deletedIndices(0).Item2
            deletedIndices.RemoveAt(0) ' Remove this entry from the deleted list
        Else
            ' No deleted slots, add at the next available position in the array
            insertIndex = boxCount
            newBoxNumber = boxCounter
        End If

        ' Create a new Box control
        Dim newBox As New Box(newBoxNumber)

        ' Calculate position for display in a grid layout (10 items per row)
        Dim row As Integer = insertIndex \ 10
        Dim col As Integer = insertIndex Mod 10
        newBox.Location = New Point(20 + col * 60, 100 + row * 60)

        ' Set properties for the box
        newBox.BoxNumber = newBoxNumber
        newBox.Text = newBoxNumber.ToString()

        ' Add the box to the array and the Form
        boxArray(insertIndex) = newBox
        Me.Controls.Add(newBox)
        Label3.Text = "Box " + newBoxNumber.ToString + " is created"
        ' Update counters
        If newBoxNumber = boxCounter Then
            boxCounter += 1
        End If
        boxCount += 1
    End Sub

    Private Sub btnDeleteBox_Click(sender As Object, e As EventArgs) Handles btnDeleteBox.Click
        Dim boxNumber As Integer
        If Integer.TryParse(numBoxNumber.Text, boxNumber) AndAlso boxNumber > 0 AndAlso boxNumber < boxCounter Then
            'check box if it exists
            Dim indexToRemove As Integer = -1
            For i As Integer = 0 To boxArray.Length - 1
                If boxArray(i) IsNot Nothing AndAlso boxArray(i).BoxNumber = boxNumber Then
                    indexToRemove = i
                    Exit For
                End If
            Next


            If indexToRemove >= 0 Then
                ' Remove the box from the Form and the array
                Me.Controls.Remove(boxArray(indexToRemove))
                boxArray(indexToRemove) = Nothing
                boxCount -= 1
                boxCounter -= 1 ' Decrement boxCounter to reflect removal

                ' Add the box to the deleted indices list
                deletedIndices.Add(Tuple.Create(indexToRemove, boxNumber))
            Else
                Label2.Text = "That NumberBox hasn't been created."
            End If
        Else
            MessageBox.Show("Invalid box number.")
        End If
    End Sub



End Class
