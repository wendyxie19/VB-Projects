﻿Public Class Box
    Inherits Button

    ' Property to hold the position number of the box
    Public Property BoxNumber As Integer

    ' Constructor to initialize the box with default size
    Public Sub New(boxNumber As Integer)
        InitializeComponent()
        Me.BoxNumber = boxNumber
        Me.Width = 50
        Me.Height = 50
        Me.Text = boxNumber.ToString()
    End Sub
End Class