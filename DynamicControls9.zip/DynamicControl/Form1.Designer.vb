﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnDeleteBox = New Button()
        numBoxNumber = New TextBox()
        btnCreateBox = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' btnDeleteBox
        ' 
        btnDeleteBox.Location = New Point(651, 12)
        btnDeleteBox.Name = "btnDeleteBox"
        btnDeleteBox.Size = New Size(128, 61)
        btnDeleteBox.TabIndex = 0
        btnDeleteBox.Text = "Remove" & vbCrLf
        btnDeleteBox.UseVisualStyleBackColor = True
        ' 
        ' numBoxNumber
        ' 
        numBoxNumber.Location = New Point(461, 50)
        numBoxNumber.Name = "numBoxNumber"
        numBoxNumber.Size = New Size(155, 23)
        numBoxNumber.TabIndex = 1
        ' 
        ' btnCreateBox
        ' 
        btnCreateBox.Location = New Point(22, 12)
        btnCreateBox.Name = "btnCreateBox"
        btnCreateBox.Size = New Size(195, 81)
        btnCreateBox.TabIndex = 2
        btnCreateBox.Text = "Spawn NumberBox"
        btnCreateBox.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(463, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(153, 15)
        Label1.TabIndex = 3
        Label1.Text = "Enter NumberBox to delete:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(464, 83)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 15)
        Label2.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(230, 17)
        Label3.Name = "Label3"
        Label3.Size = New Size(0, 15)
        Label3.TabIndex = 5
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnCreateBox)
        Controls.Add(numBoxNumber)
        Controls.Add(btnDeleteBox)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnDeleteBox As Button
    Friend WithEvents txtBoxNumber As TextBox
    Friend WithEvents btnCreateBox As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents numBoxNumber As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label

End Class
