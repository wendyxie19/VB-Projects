﻿Public Class Window
    Private myCenter As ControlCenter
    Private myNum As Integer
    Private WithEvents delayTimer As Timer

    Public Sub New(myCenter As ControlCenter, windownum As Integer, seconds As Integer)
        InitializeComponent() ' Required by the Windows Form Designer
        Me.myCenter = myCenter
        Me.myNum = windownum
        Me.Text = "Window " & windownum

        ' Initialize Timer
        delayTimer = New Timer()

        ' Start the delay timer if there’s a delay specified
        If seconds > 0 Then
            delayTimer.Interval = seconds * 1000 ' Convert seconds to milliseconds
            delayTimer.Start()
            ShowWindow()
        Else
            ShowWindow()
        End If
    End Sub

    Private Sub delayTimer_Tick(sender As Object, e As EventArgs) Handles delayTimer.Tick
        ' Stop and dispose of the timer once it ticks
        delayTimer.Stop()
        delayTimer.Dispose()
        ShowWindow()
    End Sub

    Private Sub ShowWindow()
        ' Show the window and update status in ControlCenter
        myCenter.UpdateTableStatus(myNum, "Black")
        Me.Show()
    End Sub


    Private Sub CloseButton_Click(sender As System.Object, e As System.EventArgs) Handles CloseButton.Click
        myCenter.UpdateTableStatus(myNum, "Grey") ' Update to visible status
        Close()

    End Sub


End Class