﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ControlCenter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        ShowNowButton = New Button()
        Label1 = New Label()
        Label2 = New Label()
        LinkLabel1 = New LinkLabel()
        Label3 = New Label()
        ExactMinutes = New TextBox()
        Label4 = New Label()
        ShowAtFixedDelayButton = New Button()
        ShowAtRandomDelayButton = New Button()
        Label5 = New Label()
        MinMinutes = New TextBox()
        Label6 = New Label()
        LinkLabel2 = New LinkLabel()
        Label7 = New Label()
        Label8 = New Label()
        MaxMinutes = New TextBox()
        ConfirmationTable = New DataGridView()
        WindowNumber = New DataGridViewTextBoxColumn()
        ExpectedTime = New DataGridViewTextBoxColumn()
        CType(ConfirmationTable, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' ShowNowButton
        ' 
        ShowNowButton.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        ShowNowButton.Location = New Point(164, 31)
        ShowNowButton.Margin = New Padding(4, 3, 4, 3)
        ShowNowButton.Name = "ShowNowButton"
        ShowNowButton.Size = New Size(80, 36)
        ShowNowButton.TabIndex = 0
        ShowNowButton.Text = "Now"
        ShowNowButton.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(14, 38)
        Label1.Margin = New Padding(4, 0, 4, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(113, 20)
        Label1.TabIndex = 1
        Label1.Text = "Show Window:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label2.Location = New Point(14, 122)
        Label2.Margin = New Padding(4, 0, 4, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(113, 20)
        Label2.TabIndex = 2
        Label2.Text = "Show Window:"
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        LinkLabel1.Location = New Point(164, 122)
        LinkLabel1.Margin = New Padding(4, 0, 4, 0)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(0, 20)
        LinkLabel1.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(164, 122)
        Label3.Margin = New Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(21, 20)
        Label3.TabIndex = 4
        Label3.Text = "in"
        ' 
        ' ExactMinutes
        ' 
        ExactMinutes.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        ExactMinutes.Location = New Point(190, 119)
        ExactMinutes.Margin = New Padding(4, 3, 4, 3)
        ExactMinutes.Name = "ExactMinutes"
        ExactMinutes.Size = New Size(54, 26)
        ExactMinutes.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label4.Location = New Point(252, 122)
        Label4.Margin = New Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(65, 20)
        Label4.TabIndex = 6
        Label4.Text = "minutes"
        ' 
        ' ShowAtFixedDelayButton
        ' 
        ShowAtFixedDelayButton.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        ShowAtFixedDelayButton.Location = New Point(351, 119)
        ShowAtFixedDelayButton.Margin = New Padding(4, 3, 4, 3)
        ShowAtFixedDelayButton.Name = "ShowAtFixedDelayButton"
        ShowAtFixedDelayButton.Size = New Size(70, 36)
        ShowAtFixedDelayButton.TabIndex = 7
        ShowAtFixedDelayButton.Text = "Go"
        ShowAtFixedDelayButton.UseVisualStyleBackColor = True
        ' 
        ' ShowAtRandomDelayButton
        ' 
        ShowAtRandomDelayButton.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        ShowAtRandomDelayButton.Location = New Point(439, 207)
        ShowAtRandomDelayButton.Margin = New Padding(4, 3, 4, 3)
        ShowAtRandomDelayButton.Name = "ShowAtRandomDelayButton"
        ShowAtRandomDelayButton.Size = New Size(70, 36)
        ShowAtRandomDelayButton.TabIndex = 13
        ShowAtRandomDelayButton.Text = "Go"
        ShowAtRandomDelayButton.UseVisualStyleBackColor = True
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label5.Location = New Point(345, 212)
        Label5.Margin = New Padding(4, 0, 4, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(65, 20)
        Label5.TabIndex = 12
        Label5.Text = "minutes"
        ' 
        ' MinMinutes
        ' 
        MinMinutes.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        MinMinutes.Location = New Point(190, 209)
        MinMinutes.Margin = New Padding(4, 3, 4, 3)
        MinMinutes.Name = "MinMinutes"
        MinMinutes.Size = New Size(54, 26)
        MinMinutes.TabIndex = 11
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label6.Location = New Point(164, 212)
        Label6.Margin = New Padding(4, 0, 4, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(21, 20)
        Label6.TabIndex = 10
        Label6.Text = "in"
        ' 
        ' LinkLabel2
        ' 
        LinkLabel2.AutoSize = True
        LinkLabel2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        LinkLabel2.Location = New Point(164, 212)
        LinkLabel2.Margin = New Padding(4, 0, 4, 0)
        LinkLabel2.Name = "LinkLabel2"
        LinkLabel2.Size = New Size(0, 20)
        LinkLabel2.TabIndex = 9
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label7.Location = New Point(14, 212)
        Label7.Margin = New Padding(4, 0, 4, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 20)
        Label7.TabIndex = 8
        Label7.Text = "Show Window:"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label8.Location = New Point(252, 212)
        Label8.Margin = New Padding(4, 0, 4, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(23, 20)
        Label8.TabIndex = 14
        Label8.Text = "to"
        ' 
        ' MaxMinutes
        ' 
        MaxMinutes.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        MaxMinutes.Location = New Point(284, 209)
        MaxMinutes.Margin = New Padding(4, 3, 4, 3)
        MaxMinutes.Name = "MaxMinutes"
        MaxMinutes.Size = New Size(54, 26)
        MaxMinutes.TabIndex = 15
        ' 
        ' ConfirmationTable
        ' 
        ConfirmationTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        ConfirmationTable.Columns.AddRange(New DataGridViewColumn() {WindowNumber, ExpectedTime})
        ConfirmationTable.Location = New Point(14, 288)
        ConfirmationTable.Name = "ConfirmationTable"
        ConfirmationTable.RowTemplate.Height = 25
        ConfirmationTable.Size = New Size(495, 416)
        ConfirmationTable.TabIndex = 16
        ' 
        ' WindowNumber
        ' 
        WindowNumber.Frozen = True
        WindowNumber.HeaderText = "Window"
        WindowNumber.Name = "WindowNumber"
        ' 
        ' ExpectedTime
        ' 
        ExpectedTime.Frozen = True
        ExpectedTime.HeaderText = "Shown At"
        ExpectedTime.Name = "ExpectedTime"
        ExpectedTime.ReadOnly = True
        ' 
        ' ControlCenter
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(537, 736)
        Controls.Add(ConfirmationTable)
        Controls.Add(MaxMinutes)
        Controls.Add(Label8)
        Controls.Add(ShowAtRandomDelayButton)
        Controls.Add(Label5)
        Controls.Add(MinMinutes)
        Controls.Add(Label6)
        Controls.Add(LinkLabel2)
        Controls.Add(Label7)
        Controls.Add(ShowAtFixedDelayButton)
        Controls.Add(Label4)
        Controls.Add(ExactMinutes)
        Controls.Add(Label3)
        Controls.Add(LinkLabel1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(ShowNowButton)
        Margin = New Padding(4, 3, 4, 3)
        Name = "ControlCenter"
        Text = "CPS613 Control Center Module"
        CType(ConfirmationTable, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()

    End Sub
    Friend WithEvents ShowNowButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ExactMinutes As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ShowAtFixedDelayButton As System.Windows.Forms.Button
    Friend WithEvents ShowAtRandomDelayButton As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents MinMinutes As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents MaxMinutes As TextBox
    Friend WithEvents ConfirmationTable As DataGridView
    Friend WithEvents window As DataGridViewTextBoxColumn
    Friend WithEvents ShownAt As DataGridViewTextBoxColumn
    Friend WithEvents WindowNumber As DataGridViewTextBoxColumn
    Friend WithEvents ExpectedTime As DataGridViewTextBoxColumn
End Class