﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class ControlCenter
    Private Shared windownum As Integer = 0
    Private Shared rand As New Random()

    Private Sub ShowNow_Click(sender As System.Object, e As System.EventArgs) Handles ShowNowButton.Click
        AddWindowToTable(windownum, 0)
        LaunchWindow(0)
    End Sub

    Private Sub ShowAtFixedDelay_Click(sender As System.Object, e As System.EventArgs) Handles ShowAtFixedDelayButton.Click
        Dim delay As Integer = CInt(ExactMinutes.Text) * 60
        AddWindowToTable(windownum, delay)
        LaunchWindow(delay)
    End Sub

    Private Sub ShowAtRandomDelay_Click(sender As Object, e As EventArgs) Handles ShowAtRandomDelayButton.Click
        Dim minSeconds As Integer = CInt(MinMinutes.Text) * 60
        Dim maxSeconds As Integer = CInt(MaxMinutes.Text) * 60
        Dim delay As Integer = rand.Next(minSeconds, maxSeconds + 1)
        AddWindowToTable(windownum, delay)
        LaunchWindow(delay)
    End Sub

    Private Sub LaunchWindow(seconds As Integer)
        windownum += 1
        Dim window As New Window(Me, windownum, seconds)
    End Sub

    Private Sub AddWindowToTable(windownum As Integer, seconds As Integer)
        Dim expectedTime As DateTime = DateTime.Now.AddSeconds(seconds)
        Dim rowIndex As Integer = ConfirmationTable.Rows.Add() ' Get index of new row
        Dim row As DataGridViewRow = ConfirmationTable.Rows(rowIndex)

        row.Cells("WindowNumber").Value = windownum
        row.Cells("ExpectedTime").Value = expectedTime.ToString("HH:mm:ss")

        ' Set the initial background color and text color
        row.DefaultCellStyle.BackColor = Color.White
        row.DefaultCellStyle.ForeColor = Color.Blue
    End Sub

    Public Sub UpdateTableStatus(windownum As Integer, statusColor As String)
        Debug.WriteLine($"Updating status for window {windownum} to color: {statusColor}")
        For Each row As DataGridViewRow In ConfirmationTable.Rows
            If CInt(row.Cells("WindowNumber").Value) = windownum Then
                Select Case statusColor
                    Case "Black"
                        row.DefaultCellStyle.ForeColor = Color.Black
                        Debug.WriteLine($"Set color of row {windownum} to Black")
                    Case "Grey"
                        row.DefaultCellStyle.ForeColor = Color.Gray
                        Debug.WriteLine($"Set color of row {windownum} to Grey")
                End Select
                Exit For
            End If
        Next
    End Sub

End Class
