﻿Public Class Form1
    ' Declare variables to track dragging state
    Private isDragging As Boolean = False
    Private dragStartPoint As Point

    Private Sub PictureBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown, PictureBox2.MouseDown
        If e.Button = MouseButtons.Left Then
            isDragging = True
            dragStartPoint = e.Location
            ' Bring the clicked PictureBox to the front
            Dim clickedPictureBox As PictureBox = DirectCast(sender, PictureBox)
            clickedPictureBox.BringToFront()
            ' Change cursor to hand
            Me.Cursor = Cursors.Hand
        End If
    End Sub

    Private Sub PictureBox1_MouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseMove, PictureBox2.MouseMove
        If isDragging Then
            Dim pictureBox As PictureBox = CType(sender, PictureBox)

            ' Calculate the new location for the PictureBox
            Dim newLocation As Point = pictureBox.Location + (e.Location - dragStartPoint)



            ' Update the PictureBox location
            pictureBox.Location = newLocation

            ' Update the status bar with the current coordinates of the dragged PictureBox
            ToolStripStatusLabel1.Text = $"{pictureBox.Name} - X: {newLocation.X}, Y: {newLocation.Y}"

            ' Check if the bounds of PictureBox1 overlap with PictureBox2
            If pictureBox Is PictureBox1 AndAlso PictureBox1.Bounds.IntersectsWith(PictureBox2.Bounds) Then
                ToolStripStatusLabel1.Text = ToolStripStatusLabel1.Text + " || PictureBox1 is currently over PictureBox2"
            ElseIf pictureBox Is PictureBox2 AndAlso PictureBox2.Bounds.IntersectsWith(PictureBox1.Bounds) Then
                ToolStripStatusLabel1.Text = ToolStripStatusLabel1.Text + " || PictureBox2 is currently over PictureBox1"
            End If
        End If
    End Sub

    Private Sub PictureBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseUp, PictureBox2.MouseUp

        If e.Button = MouseButtons.Left Then
            isDragging = False

            ' Reset cursor to default
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        ToolStripStatusLabel1.Text = ""
    End Sub
End Class
