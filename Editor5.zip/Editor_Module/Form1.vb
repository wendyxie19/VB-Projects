﻿Public Class Form1
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        ToolStripStatusLabel1.Text = "Ready"
        ToolStripProgressBar1.Visible = False
        ' Add any initialization after the InitializeComponent() call.

    End Sub



    Private Sub NewTool_Click(sender As Object, e As EventArgs)
        ' Logic to create a new document
    End Sub

    Private Sub OpenTool_Click(sender As Object, e As EventArgs)
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Filter = "RTF Files (*.rtf)|*.rtf"

        If openFileDialog.ShowDialog() = DialogResult.OK Then
            ToolStripStatusLabel1.Text = "Opening " & openFileDialog.FileName
            ToolStripProgressBar1.Visible = True
            ToolStripProgressBar1.Value = 0 ' Reset progress bar

            For i As Integer = 0 To 100
                ToolStripProgressBar1.Value = i
            Next

            ' Logic to load the file here...

            ToolStripStatusLabel1.Text = "Ready"
            ToolStripProgressBar1.Visible = False
        End If
    End Sub

    Private Sub SaveTool_Click(sender As Object, e As EventArgs)
        ToolStripStatusLabel1.Text = "Saving document..."
        ToolStripProgressBar1.Visible = True
        ToolStripProgressBar1.Value = 0 ' Reset progress bar

        ' Simulate saving with a delay (replace with your saving logic)
        For i As Integer = 0 To 100
            ToolStripProgressBar1.Value = i
        Next

        ' Logic to save the file here...

        ToolStripStatusLabel1.Text = "Ready"
        ToolStripProgressBar1.Visible = False
    End Sub

    Private Sub ExitTool_Click(sender As Object, e As EventArgs)
        Me.Close() ' Close the application
    End Sub

    ' Edit Menu Event Handlers
    Private Sub FontTool_Click(sender As Object, e As EventArgs)
        ' Logic to change font of the selected text
    End Sub

    Private Sub ColorTool_Click(sender As Object, e As EventArgs)
        ' Logic to change color of the selected text
    End Sub

    ' Help Menu Event Handlers
    Private Sub AboutTool_Click(sender As Object, e As EventArgs)
        MessageBox.Show("RTF Editor Version 1.0", "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    ' Toolbar Button Event Handlers
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles NewToolStripButton.Click, NewToolStripMenuItem.Click
        ' Logic to create a new document
    End Sub

    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click, OpenToolStripButton.Click
        OpenTool_Click(sender, e) ' Call the Open function
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click, SaveToolStripButton.Click
        SaveTool_Click(sender, e) ' Call the Save function
    End Sub

    Private Sub btnFont_Click(sender As Object, e As EventArgs) Handles FontToolStripMenuItem.Click, Font.Click
        FontTool_Click(sender, e) ' Call the Font function
    End Sub

    Private Sub btnColor_Click(sender As Object, e As EventArgs) Handles Colour.Click, ColorToolStripMenuItem.Click
        ColorTool_Click(sender, e) ' Call the Color function
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click, AboutToolStripButton.Click
        AboutTool_Click(sender, e) ' Call the About function
    End Sub




End Class
