﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TabControl1 = New TabControl()
        TabPage1 = New TabPage()
        AlarmCheckBox3 = New CheckBox()
        AlarmCheckBox2 = New CheckBox()
        AlarmCheckBox1 = New CheckBox()
        Clock = New TimePanel()
        TabPage2 = New TabPage()
        AlarmPanel1 = New AlarmPanel()
        TabPage3 = New TabPage()
        AlarmPanel2 = New AlarmPanel()
        TabPage4 = New TabPage()
        AlarmPanel3 = New AlarmPanel()
        KeypadPanel = New Panel()
        OKButton = New Button()
        DigitButton0 = New Button()
        TimeCancelButton = New Button()
        DigitButton9 = New Button()
        DigitButton8 = New Button()
        DigitButton7 = New Button()
        DigitButton6 = New Button()
        DigitButton5 = New Button()
        DigitButton4 = New Button()
        DigitButton3 = New Button()
        DigitButton2 = New Button()
        DigitButton1 = New Button()
        TabControl1.SuspendLayout()
        TabPage1.SuspendLayout()
        TabPage2.SuspendLayout()
        TabPage3.SuspendLayout()
        TabPage4.SuspendLayout()
        KeypadPanel.SuspendLayout()
        SuspendLayout()
        ' 
        ' TabControl1
        ' 
        TabControl1.Controls.Add(TabPage1)
        TabControl1.Controls.Add(TabPage2)
        TabControl1.Controls.Add(TabPage3)
        TabControl1.Controls.Add(TabPage4)
        TabControl1.Location = New Point(12, 12)
        TabControl1.Name = "TabControl1"
        TabControl1.SelectedIndex = 0
        TabControl1.Size = New Size(465, 396)
        TabControl1.TabIndex = 0
        ' 
        ' TabPage1
        ' 
        TabPage1.Controls.Add(AlarmCheckBox3)
        TabPage1.Controls.Add(AlarmCheckBox2)
        TabPage1.Controls.Add(AlarmCheckBox1)
        TabPage1.Controls.Add(Clock)
        TabPage1.Location = New Point(4, 24)
        TabPage1.Name = "TabPage1"
        TabPage1.Size = New Size(457, 368)
        TabPage1.TabIndex = 0
        TabPage1.Text = "Clock"
        TabPage1.UseVisualStyleBackColor = True
        ' 
        ' AlarmCheckBox3
        ' 
        AlarmCheckBox3.AutoSize = True
        AlarmCheckBox3.Location = New Point(268, 324)
        AlarmCheckBox3.Name = "AlarmCheckBox3"
        AlarmCheckBox3.Size = New Size(88, 19)
        AlarmCheckBox3.TabIndex = 3
        AlarmCheckBox3.Text = "Alarm 3 ON"
        AlarmCheckBox3.UseVisualStyleBackColor = True
        ' 
        ' AlarmCheckBox2
        ' 
        AlarmCheckBox2.AutoSize = True
        AlarmCheckBox2.Location = New Point(268, 268)
        AlarmCheckBox2.Name = "AlarmCheckBox2"
        AlarmCheckBox2.Size = New Size(88, 19)
        AlarmCheckBox2.TabIndex = 2
        AlarmCheckBox2.Text = "Alarm 2 ON"
        AlarmCheckBox2.UseVisualStyleBackColor = True
        ' 
        ' AlarmCheckBox1
        ' 
        AlarmCheckBox1.AutoSize = True
        AlarmCheckBox1.Location = New Point(268, 213)
        AlarmCheckBox1.Name = "AlarmCheckBox1"
        AlarmCheckBox1.Size = New Size(88, 19)
        AlarmCheckBox1.TabIndex = 1
        AlarmCheckBox1.Text = "Alarm 1 ON"
        AlarmCheckBox1.UseVisualStyleBackColor = True
        ' 
        ' Clock
        ' 
        Clock.Location = New Point(13, 16)
        Clock.Name = "Clock"
        Clock.Size = New Size(378, 176)
        Clock.TabIndex = 0
        ' 
        ' TabPage2
        ' 
        TabPage2.Controls.Add(AlarmPanel1)
        TabPage2.Location = New Point(4, 24)
        TabPage2.Name = "TabPage2"
        TabPage2.Size = New Size(457, 368)
        TabPage2.TabIndex = 1
        TabPage2.Text = "Alarm 1"
        TabPage2.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel1
        ' 
        AlarmPanel1.Location = New Point(3, 0)
        AlarmPanel1.Name = "AlarmPanel1"
        AlarmPanel1.Size = New Size(451, 365)
        AlarmPanel1.TabIndex = 0
        ' 
        ' TabPage3
        ' 
        TabPage3.Controls.Add(AlarmPanel2)
        TabPage3.Location = New Point(4, 24)
        TabPage3.Name = "TabPage3"
        TabPage3.Size = New Size(457, 368)
        TabPage3.TabIndex = 2
        TabPage3.Text = "Alarm 2 "
        TabPage3.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel2
        ' 
        AlarmPanel2.Location = New Point(3, 0)
        AlarmPanel2.Name = "AlarmPanel2"
        AlarmPanel2.Size = New Size(449, 372)
        AlarmPanel2.TabIndex = 0
        ' 
        ' TabPage4
        ' 
        TabPage4.Controls.Add(AlarmPanel3)
        TabPage4.Location = New Point(4, 24)
        TabPage4.Name = "TabPage4"
        TabPage4.Size = New Size(457, 368)
        TabPage4.TabIndex = 3
        TabPage4.Text = "Alarm 3"
        TabPage4.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel3
        ' 
        AlarmPanel3.Location = New Point(-4, 0)
        AlarmPanel3.Name = "AlarmPanel3"
        AlarmPanel3.Size = New Size(442, 364)
        AlarmPanel3.TabIndex = 0
        ' 
        ' KeypadPanel
        ' 
        KeypadPanel.Controls.Add(OKButton)
        KeypadPanel.Controls.Add(DigitButton0)
        KeypadPanel.Controls.Add(TimeCancelButton)
        KeypadPanel.Controls.Add(DigitButton9)
        KeypadPanel.Controls.Add(DigitButton8)
        KeypadPanel.Controls.Add(DigitButton7)
        KeypadPanel.Controls.Add(DigitButton6)
        KeypadPanel.Controls.Add(DigitButton5)
        KeypadPanel.Controls.Add(DigitButton4)
        KeypadPanel.Controls.Add(DigitButton3)
        KeypadPanel.Controls.Add(DigitButton2)
        KeypadPanel.Controls.Add(DigitButton1)
        KeypadPanel.Location = New Point(12, 450)
        KeypadPanel.Name = "KeypadPanel"
        KeypadPanel.Size = New Size(449, 418)
        KeypadPanel.TabIndex = 1
        ' 
        ' OKButton
        ' 
        OKButton.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        OKButton.Location = New Point(309, 316)
        OKButton.Margin = New Padding(2)
        OKButton.Name = "OKButton"
        OKButton.Size = New Size(79, 65)
        OKButton.TabIndex = 22
        OKButton.Text = "OK"
        OKButton.UseVisualStyleBackColor = True
        ' 
        ' DigitButton0
        ' 
        DigitButton0.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton0.Location = New Point(177, 316)
        DigitButton0.Margin = New Padding(2)
        DigitButton0.Name = "DigitButton0"
        DigitButton0.Size = New Size(79, 65)
        DigitButton0.TabIndex = 13
        DigitButton0.Text = "0"
        DigitButton0.UseVisualStyleBackColor = True
        ' 
        ' TimeCancelButton
        ' 
        TimeCancelButton.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        TimeCancelButton.Location = New Point(45, 316)
        TimeCancelButton.Margin = New Padding(2)
        TimeCancelButton.Name = "TimeCancelButton"
        TimeCancelButton.Size = New Size(79, 65)
        TimeCancelButton.TabIndex = 21
        TimeCancelButton.Text = "Cancel"
        TimeCancelButton.UseVisualStyleBackColor = True
        ' 
        ' DigitButton9
        ' 
        DigitButton9.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton9.Location = New Point(309, 223)
        DigitButton9.Margin = New Padding(2)
        DigitButton9.Name = "DigitButton9"
        DigitButton9.Size = New Size(79, 65)
        DigitButton9.TabIndex = 20
        DigitButton9.Text = "9"
        DigitButton9.UseVisualStyleBackColor = True
        ' 
        ' DigitButton8
        ' 
        DigitButton8.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton8.Location = New Point(177, 223)
        DigitButton8.Margin = New Padding(2)
        DigitButton8.Name = "DigitButton8"
        DigitButton8.Size = New Size(79, 65)
        DigitButton8.TabIndex = 19
        DigitButton8.Text = "8"
        DigitButton8.UseVisualStyleBackColor = True
        ' 
        ' DigitButton7
        ' 
        DigitButton7.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton7.Location = New Point(45, 223)
        DigitButton7.Margin = New Padding(2)
        DigitButton7.Name = "DigitButton7"
        DigitButton7.Size = New Size(79, 65)
        DigitButton7.TabIndex = 18
        DigitButton7.Text = "7"
        DigitButton7.UseVisualStyleBackColor = True
        ' 
        ' DigitButton6
        ' 
        DigitButton6.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton6.Location = New Point(309, 127)
        DigitButton6.Margin = New Padding(2)
        DigitButton6.Name = "DigitButton6"
        DigitButton6.Size = New Size(79, 65)
        DigitButton6.TabIndex = 17
        DigitButton6.Text = "6"
        DigitButton6.UseVisualStyleBackColor = True
        ' 
        ' DigitButton5
        ' 
        DigitButton5.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton5.Location = New Point(177, 127)
        DigitButton5.Margin = New Padding(2)
        DigitButton5.Name = "DigitButton5"
        DigitButton5.Size = New Size(79, 65)
        DigitButton5.TabIndex = 16
        DigitButton5.Text = "5"
        DigitButton5.UseVisualStyleBackColor = True
        ' 
        ' DigitButton4
        ' 
        DigitButton4.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton4.Location = New Point(45, 127)
        DigitButton4.Margin = New Padding(2)
        DigitButton4.Name = "DigitButton4"
        DigitButton4.Size = New Size(79, 65)
        DigitButton4.TabIndex = 15
        DigitButton4.Text = "4"
        DigitButton4.UseVisualStyleBackColor = True
        ' 
        ' DigitButton3
        ' 
        DigitButton3.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton3.Location = New Point(309, 37)
        DigitButton3.Margin = New Padding(2)
        DigitButton3.Name = "DigitButton3"
        DigitButton3.Size = New Size(79, 65)
        DigitButton3.TabIndex = 14
        DigitButton3.Text = "3"
        DigitButton3.UseVisualStyleBackColor = True
        ' 
        ' DigitButton2
        ' 
        DigitButton2.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton2.Location = New Point(177, 37)
        DigitButton2.Margin = New Padding(2)
        DigitButton2.Name = "DigitButton2"
        DigitButton2.Size = New Size(79, 65)
        DigitButton2.TabIndex = 12
        DigitButton2.Text = "2"
        DigitButton2.UseVisualStyleBackColor = True
        ' 
        ' DigitButton1
        ' 
        DigitButton1.Font = New Font("Comic Sans MS", 13.8461533F, FontStyle.Bold, GraphicsUnit.Point)
        DigitButton1.Location = New Point(45, 37)
        DigitButton1.Margin = New Padding(2)
        DigitButton1.Name = "DigitButton1"
        DigitButton1.Size = New Size(79, 65)
        DigitButton1.TabIndex = 11
        DigitButton1.Text = "1"
        DigitButton1.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(537, 880)
        Controls.Add(KeypadPanel)
        Controls.Add(TabControl1)
        Name = "Form1"
        Text = "Wendy Xie"
        TabControl1.ResumeLayout(False)
        TabPage1.ResumeLayout(False)
        TabPage1.PerformLayout()
        TabPage2.ResumeLayout(False)
        TabPage3.ResumeLayout(False)
        TabPage4.ResumeLayout(False)
        KeypadPanel.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents KeypadPanel As Panel
    Friend WithEvents OKButton As Button
    Friend WithEvents DigitButton0 As Button
    Friend WithEvents TimeCancelButton As Button
    Friend WithEvents DigitButton9 As Button
    Friend WithEvents DigitButton8 As Button
    Friend WithEvents DigitButton7 As Button
    Friend WithEvents DigitButton6 As Button
    Friend WithEvents DigitButton5 As Button
    Friend WithEvents DigitButton4 As Button
    Friend WithEvents DigitButton3 As Button
    Friend WithEvents DigitButton2 As Button
    Friend WithEvents DigitButton1 As Button
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents Clock As TimePanel
    Friend WithEvents AlarmPanel1 As AlarmPanel
    Friend WithEvents AlarmPanel2 As AlarmPanel
    Friend WithEvents AlarmPanel3 As AlarmPanel
    Friend WithEvents AlarmCheckBox2 As CheckBox
    Friend WithEvents AlarmCheckBox1 As CheckBox
    Friend WithEvents AlarmCheckBox3 As CheckBox

End Class
