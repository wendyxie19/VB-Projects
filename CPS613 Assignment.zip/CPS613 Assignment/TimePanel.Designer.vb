﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TimePanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        ColonLabel = New Label()
        ResetButton = New Button()
        SetButton = New Button()
        PMButton = New RadioButton()
        AMButton = New RadioButton()
        Digitled1 = New DigitLED()
        Digitled2 = New DigitLED()
        Digitled3 = New DigitLED()
        Digitled4 = New DigitLED()
        SuspendLayout()
        ' 
        ' ColonLabel
        ' 
        ColonLabel.AutoSize = True
        ColonLabel.Location = New Point(112, 56)
        ColonLabel.Name = "ColonLabel"
        ColonLabel.Size = New Size(10, 15)
        ColonLabel.TabIndex = 19
        ColonLabel.Text = ":"
        ' 
        ' ResetButton
        ' 
        ResetButton.Location = New Point(208, 129)
        ResetButton.Name = "ResetButton"
        ResetButton.Size = New Size(142, 37)
        ResetButton.TabIndex = 18
        ResetButton.Text = "Reset"
        ResetButton.UseVisualStyleBackColor = True
        ' 
        ' SetButton
        ' 
        SetButton.Location = New Point(35, 129)
        SetButton.Name = "SetButton"
        SetButton.Size = New Size(142, 37)
        SetButton.TabIndex = 17
        SetButton.Text = "Set"
        SetButton.UseVisualStyleBackColor = True
        ' 
        ' PMButton
        ' 
        PMButton.AutoSize = True
        PMButton.Location = New Point(253, 77)
        PMButton.Name = "PMButton"
        PMButton.Size = New Size(43, 19)
        PMButton.TabIndex = 16
        PMButton.TabStop = True
        PMButton.Text = "PM"
        PMButton.UseVisualStyleBackColor = True
        ' 
        ' AMButton
        ' 
        AMButton.AutoSize = True
        AMButton.Location = New Point(253, 35)
        AMButton.Name = "AMButton"
        AMButton.Size = New Size(44, 19)
        AMButton.TabIndex = 15
        AMButton.TabStop = True
        AMButton.Text = "AM"
        AMButton.UseVisualStyleBackColor = True
        ' 
        ' Digitled1
        ' 
        Digitled1.AutoSize = True
        Digitled1.Location = New Point(26, 52)
        Digitled1.MaxDigit = 1
        Digitled1.Name = "Digitled1"
        Digitled1.Size = New Size(13, 15)
        Digitled1.TabIndex = 20
        Digitled1.Text = "0"
        ' 
        ' Digitled2
        ' 
        Digitled2.AutoSize = True
        Digitled2.Location = New Point(68, 52)
        Digitled2.MaxDigit = 9
        Digitled2.Name = "Digitled2"
        Digitled2.Size = New Size(13, 30)
        Digitled2.TabIndex = 21
        Digitled2.Text = "0" & vbCrLf & vbCrLf
        ' 
        ' Digitled3
        ' 
        Digitled3.AutoSize = True
        Digitled3.Location = New Point(140, 52)
        Digitled3.MaxDigit = 5
        Digitled3.Name = "Digitled3"
        Digitled3.Size = New Size(13, 15)
        Digitled3.TabIndex = 22
        Digitled3.Text = "0"
        ' 
        ' Digitled4
        ' 
        Digitled4.AutoSize = True
        Digitled4.Location = New Point(186, 53)
        Digitled4.MaxDigit = 9
        Digitled4.Name = "Digitled4"
        Digitled4.Size = New Size(13, 15)
        Digitled4.TabIndex = 23
        Digitled4.Text = "0"
        ' 
        ' TimePanel
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(Digitled4)
        Controls.Add(Digitled3)
        Controls.Add(Digitled2)
        Controls.Add(Digitled1)
        Controls.Add(ColonLabel)
        Controls.Add(ResetButton)
        Controls.Add(SetButton)
        Controls.Add(PMButton)
        Controls.Add(AMButton)
        Name = "TimePanel"
        Size = New Size(397, 215)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ColonLabel As Label
    Friend WithEvents ResetButton As Button
    Friend WithEvents SetButton As Button
    Friend WithEvents PMButton As RadioButton
    Friend WithEvents AMButton As RadioButton
    Friend WithEvents Digitled1 As DigitLED
    Friend WithEvents Digitled2 As DigitLED
    Friend WithEvents Digitled3 As DigitLED
    Friend WithEvents Digitled4 As DigitLED

End Class
