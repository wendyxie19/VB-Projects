﻿Public Class DigitLED
    Inherits Label

    Private _maxDigit As Integer
    Public Sub New()
        InitializeComponent()
        Me.Text = "0"
    End Sub


    Property MaxDigit As Integer
        Get
            Return _maxDigit
        End Get
        Set(value As Integer)
            _maxDigit = value
        End Set
    End Property


    Public Function GetDigit()
        Return Me.Text

    End Function

    Public Sub SetDigit(newDigit)
        Me.Text = newDigit

    End Sub
End Class
