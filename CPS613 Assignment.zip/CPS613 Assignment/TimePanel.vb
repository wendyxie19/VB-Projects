﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock

Public Class TimePanel
    Private digitLeds() As DigitLED

    Private oldtime As String

    Private currentDigitIndex As Integer

    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()

        digitLeds = {Digitled1, Digitled2, Digitled3, Digitled4}
        ' Set the default radio button to AM
        AMButton.Checked = True
        setOldTime()
        ZeroFormat()
        currentDigitIndex = 0


    End Sub
    Public Sub setcurrentDigitIndex(index As Integer)
        currentDigitIndex = index


    End Sub
    Public Function GetTime() As TimeOnly
        Dim hour As Integer = Digitled1.GetDigit() * 10 + Digitled2.GetDigit() ' Combine first two digits for the hour
        Dim minute As Integer = Digitled3.GetDigit() * 10 + Digitled4.GetDigit() ' Combine last two digits for the minutes

        If hour = 12 And AMButton.Checked Then
            hour = 0
        End If
        If hour > 12 And PMButton.Checked Then
            hour = hour + 12
        End If

        ' Create TimeOnly object with the correct hour and minute
        Dim curTime As New TimeOnly(hour, minute)

        Return curTime

    End Function

    Public Sub SetTime(pressedDigit As String)
        ' Ensure that the digit is valid for the current digit
        If currentDigitIndex <= digitLeds.Length - 1 Then
            ' Update the current digit displayed on the DigitLED
            digitLeds(currentDigitIndex).SetDigit(pressedDigit)

            ' Move to the next digit, if needed
            currentDigitIndex += 1
        End If


    End Sub
    Public Sub SetCurrentTime(currentTime As TimeOnly)
        'cross thread issue solution
        If AMButton.InvokeRequired Then
            AMButton.Invoke(New Action(Of TimeOnly)(AddressOf SetCurrentTime), currentTime)
            Return
        End If

        Dim hour As Integer = currentTime.Hour
        Dim minute As Integer = currentTime.Minute

        ' Set AM/PM based on the current time
        If hour >= 12 Then
            PMButton.Checked = True
            If hour > 12 Then
                hour = hour - 12 ' Convert 24-hour format to 12-hour format
            End If
        Else

            If hour = 0 Then
                hour = 12 ' Midnight case

            End If
        End If

        ' Set the time in the DigitLEDs (assuming two LEDs for hour, two for minute)
        digitLeds(0).SetDigit(hour \ 10) ' Tens place of the hour
        digitLeds(1).SetDigit(hour Mod 10) ' Ones place of the hour
        digitLeds(2).SetDigit(minute \ 10) ' Tens place of the minute
        digitLeds(3).SetDigit(minute Mod 10) ' Ones place of the minute
    End Sub
    Public Function CurrentDigit() As DigitLED
        If currentDigitIndex <= digitLeds.Length - 1 Then
            Return digitLeds(currentDigitIndex)
        End If
        Return Nothing
    End Function

    Public Sub setOldTime()
        oldtime = Digitled1.GetDigit() + Digitled2.GetDigit() + Digitled3.GetDigit() + Digitled4.GetDigit()

    End Sub
    Public Function getOldTime()
        Return oldtime
    End Function
    Private Sub ZeroFormat()
        'Reset time to 00: 00 AM
        For Each led In digitLeds
            led.SetDigit(0) ' Reset each digit LED to 0
        Next
        currentDigitIndex = 0

    End Sub
    Private Sub ResetButton_Click(sender As Object, e As EventArgs) Handles ResetButton.Click
        Dim activeTabIndex As Integer = Form1.TabControl1.SelectedIndex
        If activeTabIndex = 0 Then
            SetCurrentTime(TimeOnly.FromDateTime(DateTime.Now))

        Else
            ZeroFormat()

        End If
    End Sub

    Private Sub SetButton_Click(sender As Object, e As EventArgs) Handles SetButton.Click
        setOldTime()
        Form1.SetActiveTimePanel(Form1.ActiveTimePanel())
        Form1.UpdateDigitButtons()
        ZeroFormat()
        SetButton.Enabled = False
        ResetButton.Enabled = False
        Form1.ShowKeypad()
    End Sub


End Class
