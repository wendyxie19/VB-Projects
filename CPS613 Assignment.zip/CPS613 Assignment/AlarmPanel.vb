﻿Imports System.IO
Imports System.Media

Public Class AlarmPanel
    ' Variable to store the selected sound
    Private selectedSound As SoundPlayer


    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        ' Get selected item
        Dim selectedItem As String = ListBox1.SelectedItem.ToString()

        'DIDN"T WORK**
        'Select Case selectedItem
        '    Case "Bird"
        '      selectedSound = New SoundPlayer(My.Resources.bird)
        '    Case "Boat Horn"
        '        selectedSound = New SoundPlayer(My.Resources.boat_horn)
        '    Case "Cow"
        '        selectedSound = New SoundPlayer(My.Resources.cow)
        '    Case "Crickets"
        '        selectedSound = New SoundPlayer(My.Resources.crickets)
        '    Case "Drum Roll"
        '        selectedSound = New SoundPlayer(My.Resources.drumRoll)
        '    Case "Fanfare"
        '        selectedSound = New SoundPlayer(My.Resources.fanfare)
        '    Case "Train"
        '        selectedSound = New SoundPlayer(My.Resources.train)
        'End Select
    End Sub

    ' Method to play the selected sound
    Public Sub PlaySound()
        If selectedSound IsNot Nothing Then
            selectedSound.Play()
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        Form1.UpdateClockCheckBoxes()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class
