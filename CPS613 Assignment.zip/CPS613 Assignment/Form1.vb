﻿Imports Microsoft.VisualBasic.Devices
Imports System.Timers
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class Form1
    Private digitButtons() As Button
    Private timePanels As TimePanel()
    Private alarmPanels As AlarmPanel()

    Private alarmTimes As TimeOnly()
    Private alarms As System.Windows.Forms.CheckBox()
    Private alarmsPages As System.Windows.Forms.CheckBox()
    Private atp As TimePanel
    Private WithEvents clockTimer As New Timer()
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        digitButtons = {
            DigitButton0, DigitButton1, DigitButton2,
            DigitButton3, DigitButton4, DigitButton5,
            DigitButton6, DigitButton7, DigitButton8,
            DigitButton9
        }

        timePanels = {
            Clock,
            AlarmPanel1.TimePanel1,
            AlarmPanel2.TimePanel1,
            AlarmPanel3.TimePanel1
        }
        alarmTimes = {Nothing, Nothing, Nothing}


        alarms = {AlarmCheckBox1, AlarmCheckBox2, AlarmCheckBox3
            }
        alarmsPages = {AlarmPanel1.CheckBox1, AlarmPanel2.CheckBox1, AlarmPanel3.CheckBox1}

        alarmPanels = {AlarmPanel1, AlarmPanel2, AlarmPanel3}
        AlarmPanel1.Button1.Image = My.Resources.Ball
        AlarmPanel2.Button1.Image = My.Resources.Oil_lamp

        AlarmPanel3.Button1.Image = My.Resources.World



        HideKeypad()
        ' Set the timer interval to 1 minute 
        clockTimer.Interval = 60000
        clockTimer.Start()
        atp = Clock

        timePanels(0).SetCurrentTime(TimeOnly.FromDateTime(DateTime.Now))

    End Sub
    Public Sub SetActiveTimePanel(newATP As TimePanel)
        atp = newATP
    End Sub

    Public Function ActiveTimePanel()
        Dim activeTabIndex As Integer = TabControl1.SelectedIndex

        ' Access the active TimePanel directly from the array
        Dim atp As TimePanel = timePanels(activeTabIndex)
        Return atp

    End Function
    Public Sub ShowKeypad()
        For Each panel In timePanels
            panel.SetButton.Enabled = False
            panel.ResetButton.Enabled = False
        Next
        KeypadPanel.Visible = True
        Me.Size = New Size(Me.Width, Me.Height + KeypadPanel.Height) ' Adjust form size

    End Sub

    Private Sub HideKeypad()
        For Each panel In timePanels
            panel.SetButton.Enabled = True
            panel.ResetButton.Enabled = True
        Next
        KeypadPanel.Visible = False
        Me.Size = New Size(Me.Width, Me.Height - KeypadPanel.Height) ' Reset form size
    End Sub
    Public Sub UpdateDigitButtons()


        Dim currentDigit As DigitLED = atp.CurrentDigit()

        If atp.Digitled1.GetDigit = "1" Then
            atp.Digitled2.MaxDigit = "2"
        Else
            atp.Digitled2.MaxDigit = "9"

        End If
        If currentDigit IsNot Nothing Then
            OKButton.Enabled = False
            Dim maxDigit As Integer = currentDigit.MaxDigit

            ' Enable/Disable buttons based on the current MaxDigit
            For i As Integer = 0 To digitButtons.Length - 1
                If i <= maxDigit Then
                    digitButtons(i).Enabled = True ' Enable button if it's a valid digit
                Else
                    digitButtons(i).Enabled = False ' Disable button if it's greater than MaxDigit
                End If
            Next
        Else
            ' If CurrentDigit is Nothing, disable all digit buttons and enable OKButton
            For i As Integer = 0 To digitButtons.Length - 1
                digitButtons(i).Enabled = False
            Next
            OKButton.Enabled = True
        End If
    End Sub

    Private Sub DigitButton_Click(sender As Object, e As EventArgs) Handles DigitButton1.Click, DigitButton2.Click,
    DigitButton3.Click, DigitButton4.Click, DigitButton5.Click, DigitButton6.Click, DigitButton7.Click, DigitButton8.Click,
    DigitButton9.Click, DigitButton0.Click

        Dim button As Button = CType(sender, Button)
        Dim pressedDigit As String = button.Text

        atp.SetTime(pressedDigit) ' Call the method to handle input
        UpdateDigitButtons()
    End Sub
    Private Sub clockTimer_Elapsed(sender As Object, e As ElapsedEventArgs) Handles clockTimer.Elapsed
        Dim currentTime As TimeOnly = timePanels(0).GetTime() ' Get current time
        currentTime = currentTime.AddMinutes(1) ' Add one minute
        timePanels(0).SetCurrentTime(currentTime) ' Set the new time

        ' Check each enabled alarm
        CheckAlarms()

    End Sub

    Private Sub CheckAlarms()
        Dim currentTime As TimeOnly = timePanels(0).GetTime()

        ' Loop through each alarm and check if it's enabled and matches the current time
        For i As Integer = 0 To 2
            If alarms(i).Checked And alarmTimes(i) <> Nothing Then

                ' Compare current time with alarm time
                If alarmTimes(i).Hour = currentTime.Hour And alarmTimes(i).Minute = currentTime.Minute Then
                    alarmPanels(i).PlaySound() ' ***DOESN'T WORK
                    MessageBox.Show("Alarm Ringing") ' alternate way to alert

                End If
            End If
        Next
    End Sub

    Private Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click
        atp.setcurrentDigitIndex(0)

        Dim timeindex As Integer = Array.IndexOf(timePanels, atp) - 1
        If timeindex >= 0 Then
            alarmTimes(timeindex) = atp.GetTime()
        End If
        HideKeypad()
        UpdateDigitButtons()
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles TimeCancelButton.Click
        atp.setcurrentDigitIndex(0)

        For i As Integer = 0 To 3

            Dim digit As String = atp.getOldTime(i)

            atp.SetTime(digit) ' Call the SetTime method for each digit
        Next
        HideKeypad()
        atp.setcurrentDigitIndex(0)
        UpdateDigitButtons()
    End Sub

    Private Sub AlarmCheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles AlarmCheckBox1.CheckedChanged

        AlarmPanel1.CheckBox1.Checked = AlarmCheckBox1.Checked

    End Sub

    Private Sub AlarmCheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles AlarmCheckBox2.CheckedChanged
        AlarmPanel2.CheckBox1.Checked = AlarmCheckBox2.Checked
    End Sub

    Private Sub AlarmCheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles AlarmCheckBox3.CheckedChanged
        AlarmPanel3.CheckBox1.Checked = AlarmCheckBox3.Checked

    End Sub
    Public Sub UpdateClockCheckBoxes()
        AlarmCheckBox1.Checked = AlarmPanel1.CheckBox1.Checked
        AlarmCheckBox2.Checked = AlarmPanel2.CheckBox1.Checked
        AlarmCheckBox3.Checked = AlarmPanel3.CheckBox1.Checked
    End Sub
End Class