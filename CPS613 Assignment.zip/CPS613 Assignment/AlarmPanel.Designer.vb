﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AlarmPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        CheckBox1 = New CheckBox()
        ListBox1 = New ListBox()
        Button1 = New Button()
        TimePanel1 = New TimePanel()
        SuspendLayout()
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(199, 339)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(79, 19)
        CheckBox1.TabIndex = 6
        CheckBox1.Text = "Alarm ON" & vbCrLf
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' ListBox1
        ' 
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Items.AddRange(New Object() {"Bird", "Boat Horn", "Cow", "Crickets", "Drum Roll", "Fanfare", "Train"})
        ListBox1.Location = New Point(199, 223)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(163, 109)
        ListBox1.TabIndex = 5
        ' 
        ' Button1
        ' 
        Button1.Image = My.Resources.Resources.Oil_lamp
        Button1.Location = New Point(30, 215)
        Button1.Name = "Button1"
        Button1.Size = New Size(135, 117)
        Button1.TabIndex = 4
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TimePanel1
        ' 
        TimePanel1.Location = New Point(13, 14)
        TimePanel1.Name = "TimePanel1"
        TimePanel1.Size = New Size(398, 195)
        TimePanel1.TabIndex = 7
        ' 
        ' AlarmPanel
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(TimePanel1)
        Controls.Add(CheckBox1)
        Controls.Add(ListBox1)
        Controls.Add(Button1)
        Name = "AlarmPanel"
        Size = New Size(442, 364)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TimePanel1 As TimePanel

End Class
